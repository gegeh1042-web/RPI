/*
  # RPI Assessment System Database Schema

  ## Overview
  Creates the database structure for the Relationship Possessiveness Index (RPI) assessment platform.
  
  ## New Tables
  
  ### `questions`
  Stores the assessment question bank with 20 questions across 4 dimensions.
  - `id` (integer, primary key): Question identifier
  - `dimension` (text): One of 'control', 'jealousy', 'dependence', 'anxiety'
  - `content` (text): Question content in Chinese
  - `order_index` (integer): Display order within dimension
  - `created_at` (timestamptz): Creation timestamp
  
  ### `rpi_results`
  Stores anonymous assessment results for analytics.
  - `id` (uuid, primary key): Result identifier
  - `session_id` (text, unique): Anonymous session identifier
  - `control_score` (integer): Control dimension score (0-100)
  - `jealousy_score` (integer): Jealousy dimension score (0-100)
  - `dependence_score` (integer): Dependence dimension score (0-100)
  - `anxiety_score` (integer): Anxiety dimension score (0-100)
  - `total_score` (integer): Overall RPI score (0-100)
  - `answers` (jsonb): Array of user answers [1-5]
  - `created_at` (timestamptz): Assessment completion time
  
  ## Security
  - Enable RLS on all tables
  - Public read access to questions
  - Public insert access to results (anonymous)
  - No update/delete access for privacy protection
  
  ## Notes
  - Session IDs are generated client-side for privacy
  - No personal information is collected
  - Results are retained for analytics only
*/

CREATE TABLE IF NOT EXISTS questions (
  id integer PRIMARY KEY,
  dimension text NOT NULL CHECK (dimension IN ('control', 'jealousy', 'dependence', 'anxiety')),
  content text NOT NULL,
  order_index integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS rpi_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id text UNIQUE NOT NULL,
  control_score integer NOT NULL CHECK (control_score >= 0 AND control_score <= 100),
  jealousy_score integer NOT NULL CHECK (jealousy_score >= 0 AND jealousy_score <= 100),
  dependence_score integer NOT NULL CHECK (dependence_score >= 0 AND dependence_score <= 100),
  anxiety_score integer NOT NULL CHECK (anxiety_score >= 0 AND anxiety_score <= 100),
  total_score integer NOT NULL CHECK (total_score >= 0 AND total_score <= 100),
  answers jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE rpi_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Questions are publicly readable"
  ON questions
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert results"
  ON rpi_results
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Results are publicly readable"
  ON rpi_results
  FOR SELECT
  TO anon, authenticated
  USING (true);

INSERT INTO questions (id, dimension, content, order_index) VALUES
  (1, 'control', '我会经常查看伴侣的手机和社交媒体', 1),
  (2, 'control', '我会限制伴侣的穿着风格', 2),
  (3, 'control', '我需要知道伴侣的行踪和社交计划', 3),
  (4, 'control', '我不喜欢伴侣独自参加社交活动', 4),
  (5, 'control', '我会要求伴侣优先考虑我的意见和需求', 5),
  (6, 'jealousy', '看到伴侣与异性密切互动时，我会感到不安', 1),
  (7, 'jealousy', '我会因为伴侣关注他人而感到嫉妒', 2),
  (8, 'jealousy', '我经常想象伴侣可能对别人有好感', 3),
  (9, 'jealousy', '我不喜欢伴侣谈论前任或其他异性', 4),
  (10, 'jealousy', '我会因为伴侣与他人的友谊而感到威胁', 5),
  (11, 'dependence', '我需要伴侣时刻关注我的情绪', 1),
  (12, 'dependence', '没有伴侣的陪伴，我会感到空虚', 2),
  (13, 'dependence', '我的自我价值很大程度上取决于这段关系', 3),
  (14, 'dependence', '我需要伴侣频繁地表达爱意和关心', 4),
  (15, 'dependence', '我难以独自完成重要决定', 5),
  (16, 'anxiety', '我经常担心被伴侣抛弃', 1),
  (17, 'anxiety', '我害怕伴侣会离开我去找更好的人', 2),
  (18, 'anxiety', '伴侣的冷淡会让我感到极度不安', 3),
  (19, 'anxiety', '我经常需要伴侣确认对我的爱', 4),
  (20, 'anxiety', '我担心这段关系随时可能结束', 5)
ON CONFLICT (id) DO NOTHING;