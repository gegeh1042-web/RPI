import { Answer, DimensionScore, RPIResult, Question } from '../types/rpi';

export function calculateRPIScores(answers: Answer[], questions: Question[]): RPIResult {
  const dimensionAnswers: Record<string, number[]> = {
    control: [],
    jealousy: [],
    dependence: [],
    anxiety: []
  };

  answers.forEach(answer => {
    const question = questions.find(q => q.id === answer.questionId);
    if (question) {
      dimensionAnswers[question.dimension].push(answer.value);
    }
  });

  const dimensionScores: DimensionScore = {
    control: calculateDimensionScore(dimensionAnswers.control),
    jealousy: calculateDimensionScore(dimensionAnswers.jealousy),
    dependence: calculateDimensionScore(dimensionAnswers.dependence),
    anxiety: calculateDimensionScore(dimensionAnswers.anxiety)
  };

  const totalScore = Math.round(
    (dimensionScores.control +
     dimensionScores.jealousy +
     dimensionScores.dependence +
     dimensionScores.anxiety) / 4
  );

  const { level, levelDescription } = getLevelInfo(totalScore);

  const sessionId = generateSessionId();

  return {
    sessionId,
    dimensionScores,
    totalScore,
    level,
    levelDescription
  };
}

function calculateDimensionScore(values: number[]): number {
  if (values.length === 0) return 0;
  const average = values.reduce((sum, val) => sum + val, 0) / values.length;
  return Math.round((average / 5) * 100);
}

function getLevelInfo(score: number): { level: string; levelDescription: string } {
  if (score <= 30) {
    return {
      level: '自由自在',
      levelDescription: '你在恋爱关系中保持着健康的独立性，给予伴侣充分的自由空间。'
    };
  } else if (score <= 70) {
    return {
      level: '恰到好处',
      levelDescription: '你在关系中找到了较好的平衡，既重视伴侣又保持适度的独立性。'
    };
  } else {
    return {
      level: '爱到极致',
      levelDescription: '你对伴侣有较强的占有欲，可能需要适当调整以维护健康的关系。'
    };
  }
}

function generateSessionId(): string {
  return `rpi_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
}

export function getRecommendations(dimensionScores: DimensionScore, totalScore: number): string[] {
  const recommendations: string[] = [];

  if (dimensionScores.control > 70) {
    recommendations.push('尝试给予伴侣更多的个人空间，信任是关系的基石。');
  } else if (dimensionScores.control < 30) {
    recommendations.push('适度关心伴侣的生活，让对方感受到你的在意。');
  }

  if (dimensionScores.jealousy > 70) {
    recommendations.push('练习管理嫉妒情绪，多关注自己的成长和价值。');
  }

  if (dimensionScores.dependence > 70) {
    recommendations.push('培养个人兴趣爱好，建立独立的社交圈和自我价值感。');
  } else if (dimensionScores.dependence < 30) {
    recommendations.push('在关系中展现更多的情感需求，让伴侣了解你的真实感受。');
  }

  if (dimensionScores.anxiety > 70) {
    recommendations.push('学习建立安全感，可以尝试与伴侣进行开放式沟通。');
  }

  if (totalScore > 70) {
    recommendations.push('考虑寻求专业心理咨询，探索占有欲背后的深层原因。');
  }

  if (recommendations.length === 0) {
    recommendations.push('继续保持健康的关系模式，相互尊重和理解。');
  }

  return recommendations;
}
