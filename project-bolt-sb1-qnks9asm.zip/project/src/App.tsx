import { useState, useEffect } from 'react';
import { Home } from './pages/Home';
import { Test } from './pages/Test';
import { Result } from './pages/Result';
import { Answer, Question } from './types/rpi';
import { supabase } from './lib/supabase';

type Page = 'home' | 'test' | 'result';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);

  useEffect(() => {
    loadQuestions();
  }, []);

  async function loadQuestions() {
    try {
      const { data, error } = await supabase
        .from('questions')
        .select('*')
        .order('id');

      if (error) throw error;
      setQuestions(data || []);
    } catch (error) {
      console.error('Failed to load questions:', error);
    }
  }

  function handleStart() {
    setCurrentPage('test');
  }

  function handleComplete(completedAnswers: Answer[]) {
    setAnswers(completedAnswers);
    setCurrentPage('result');
  }

  function handleRestart() {
    setAnswers([]);
    setCurrentPage('home');
  }

  function handleBack() {
    setCurrentPage('home');
  }

  return (
    <>
      {currentPage === 'home' && <Home onStart={handleStart} />}
      {currentPage === 'test' && (
        <Test onComplete={handleComplete} onBack={handleBack} />
      )}
      {currentPage === 'result' && (
        <Result
          answers={answers}
          questions={questions}
          onRestart={handleRestart}
        />
      )}
    </>
  );
}

export default App;
