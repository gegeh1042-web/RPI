export type Dimension = 'control' | 'jealousy' | 'dependence' | 'anxiety';

export interface Question {
  id: number;
  dimension: Dimension;
  content: string;
  order_index: number;
}

export interface Answer {
  questionId: number;
  value: number;
}

export interface DimensionScore {
  control: number;
  jealousy: number;
  dependence: number;
  anxiety: number;
}

export interface RPIResult {
  sessionId: string;
  dimensionScores: DimensionScore;
  totalScore: number;
  level: string;
  levelDescription: string;
}

export const DIMENSION_NAMES: Record<Dimension, string> = {
  control: '控制欲望',
  jealousy: '嫉妒倾向',
  dependence: '情感依赖',
  anxiety: '关系不安'
};

export const OPTIONS = [
  { value: 1, label: '从不' },
  { value: 2, label: '偶尔' },
  { value: 3, label: '有时' },
  { value: 4, label: '经常' },
  { value: 5, label: '总是' }
];
