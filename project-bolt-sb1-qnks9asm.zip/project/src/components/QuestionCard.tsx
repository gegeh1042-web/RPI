import { Question } from '../types/rpi';
import { OPTIONS } from '../types/rpi';

interface QuestionCardProps {
  question: Question;
  currentValue?: number;
  onAnswer: (value: number) => void;
}

export function QuestionCard({ question, currentValue, onAnswer }: QuestionCardProps) {
  return (
    <div className="bg-white rounded-2xl shadow-lg p-8 max-w-2xl w-full">
      <div className="mb-8">
        <p className="text-xl md:text-2xl text-gray-800 font-medium leading-relaxed">
          {question.content}
        </p>
      </div>

      <div className="space-y-3">
        {OPTIONS.map((option) => (
          <button
            key={option.value}
            onClick={() => onAnswer(option.value)}
            className={`w-full p-4 rounded-xl text-left transition-all duration-200 ${
              currentValue === option.value
                ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-md transform scale-105'
                : 'bg-gray-50 text-gray-700 hover:bg-gray-100 hover:shadow-md'
            }`}
          >
            <span className="text-lg font-medium">{option.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
