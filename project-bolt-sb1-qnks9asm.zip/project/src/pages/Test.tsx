import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Question, Answer } from '../types/rpi';
import { QuestionCard } from '../components/QuestionCard';
import { ProgressBar } from '../components/ProgressBar';
import { supabase } from '../lib/supabase';

interface TestProps {
  onComplete: (answers: Answer[]) => void;
  onBack: () => void;
}

export function Test({ onComplete, onBack }: TestProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadQuestions();
  }, []);

  async function loadQuestions() {
    try {
      const { data, error } = await supabase
        .from('questions')
        .select('*')
        .order('id');

      if (error) throw error;

      const shuffled = [...(data || [])].sort(() => Math.random() - 0.5);
      setQuestions(shuffled);
    } catch (error) {
      console.error('Failed to load questions:', error);
    } finally {
      setLoading(false);
    }
  }

  function handleAnswer(value: number) {
    const currentQuestion = questions[currentIndex];
    const newAnswers = answers.filter(a => a.questionId !== currentQuestion.id);
    newAnswers.push({ questionId: currentQuestion.id, value });
    setAnswers(newAnswers);

    if (currentIndex < questions.length - 1) {
      setTimeout(() => setCurrentIndex(currentIndex + 1), 300);
    } else {
      setTimeout(() => onComplete(newAnswers), 300);
    }
  }

  function handlePrevious() {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  }

  function getCurrentAnswer(): number | undefined {
    const currentQuestion = questions[currentIndex];
    return answers.find(a => a.questionId === currentQuestion.id)?.value;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block w-12 h-12 border-4 border-pink-500 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-gray-600">加载测评题目...</p>
        </div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">无法加载测评题目</p>
          <button
            onClick={onBack}
            className="text-pink-600 hover:text-pink-700 font-medium"
          >
            返回首页
          </button>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-pink-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-2xl mb-4">
        <button
          onClick={onBack}
          className="text-gray-600 hover:text-gray-800 font-medium flex items-center gap-2 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
          返回首页
        </button>
      </div>

      <ProgressBar current={currentIndex + 1} total={questions.length} />

      <QuestionCard
        question={currentQuestion}
        currentValue={getCurrentAnswer()}
        onAnswer={handleAnswer}
      />

      <div className="flex gap-4 mt-6 max-w-2xl w-full">
        <button
          onClick={handlePrevious}
          disabled={currentIndex === 0}
          className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
            currentIndex === 0
              ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
              : 'bg-white text-gray-700 hover:bg-gray-50 shadow-md'
          }`}
        >
          <ChevronLeft className="w-5 h-5" />
          上一题
        </button>

        {getCurrentAnswer() && (
          <button
            onClick={() => handleAnswer(getCurrentAnswer()!)}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-medium bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:shadow-lg transition-all"
          >
            {currentIndex === questions.length - 1 ? '查看结果' : '下一题'}
            <ChevronRight className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}
