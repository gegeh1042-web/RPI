import { useEffect, useState } from 'react';
import { Heart, Share2, RotateCcw, TrendingUp } from 'lucide-react';
import { RPIResult, Question, Answer, DIMENSION_NAMES } from '../types/rpi';
import { RadarChart } from '../components/RadarChart';
import { calculateRPIScores, getRecommendations } from '../lib/rpiCalculator';
import { supabase } from '../lib/supabase';

interface ResultProps {
  answers: Answer[];
  questions: Question[];
  onRestart: () => void;
}

export function Result({ answers, questions, onRestart }: ResultProps) {
  const [result, setResult] = useState<RPIResult | null>(null);
  const [recommendations, setRecommendations] = useState<string[]>([]);
  const [saving, setSaving] = useState(true);

  useEffect(() => {
    const calculatedResult = calculateRPIScores(answers, questions);
    setResult(calculatedResult);
    setRecommendations(getRecommendations(calculatedResult.dimensionScores, calculatedResult.totalScore));
    saveResult(calculatedResult);
  }, [answers, questions]);

  async function saveResult(result: RPIResult) {
    try {
      const { error } = await supabase.from('rpi_results').insert({
        session_id: result.sessionId,
        control_score: result.dimensionScores.control,
        jealousy_score: result.dimensionScores.jealousy,
        dependence_score: result.dimensionScores.dependence,
        anxiety_score: result.dimensionScores.anxiety,
        total_score: result.totalScore,
        answers: answers
      });

      if (error) throw error;
    } catch (error) {
      console.error('Failed to save result:', error);
    } finally {
      setSaving(false);
    }
  }

  function handleShare() {
    const text = `我完成了RPI恋爱占有欲指数测评，总分${result?.totalScore}分，等级：${result?.level}。快来测测你的占有欲程度吧！`;

    if (navigator.share) {
      navigator.share({
        title: 'RPI恋爱占有欲指数测评',
        text: text
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text).then(() => {
        alert('结果已复制到剪贴板！');
      });
    }
  }

  if (!result) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-pink-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block w-12 h-12 border-4 border-pink-500 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-gray-600">正在分析您的测评结果...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-pink-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full mb-4 shadow-lg">
            <Heart className="w-8 h-8 text-white" fill="currentColor" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
            您的测评结果
          </h1>
          {saving && (
            <p className="text-sm text-gray-500">正在保存结果...</p>
          )}
        </div>

        <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12 mb-6">
          <div className="text-center mb-8">
            <div className="inline-block relative">
              <div className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent">
                {result.totalScore}
              </div>
              <div className="text-sm text-gray-500 mt-1">/ 100</div>
            </div>
            <div className="mt-4">
              <span className="inline-block px-6 py-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-full text-lg font-semibold">
                {result.level}
              </span>
            </div>
            <p className="text-gray-600 mt-4 text-lg">
              {result.levelDescription}
            </p>
          </div>

          <div className="border-t border-gray-200 pt-8 mb-8">
            <h2 className="text-xl font-bold text-gray-800 mb-6 text-center">
              四维度分析
            </h2>
            <RadarChart scores={result.dimensionScores} />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {(Object.keys(result.dimensionScores) as Array<keyof typeof result.dimensionScores>).map((key) => (
              <div
                key={key}
                className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-xl p-4 text-center"
              >
                <div className="text-2xl font-bold text-gray-800 mb-1">
                  {result.dimensionScores[key]}
                </div>
                <div className="text-sm text-gray-600">
                  {DIMENSION_NAMES[key]}
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-200 pt-8">
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-pink-500" />
              改善建议
            </h2>
            <div className="space-y-3">
              {recommendations.map((rec, index) => (
                <div
                  key={index}
                  className="flex gap-3 p-4 bg-gradient-to-r from-pink-50 to-purple-50 rounded-xl"
                >
                  <span className="flex-shrink-0 w-6 h-6 bg-gradient-to-br from-pink-500 to-purple-600 text-white rounded-full flex items-center justify-center text-sm font-semibold">
                    {index + 1}
                  </span>
                  <p className="text-gray-700 leading-relaxed">{rec}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-200 pt-8 mt-8">
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="font-bold text-gray-800 mb-3">关于测评结果</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                本测评结果基于您当前的回答生成，反映的是您此刻在亲密关系中的状态。
                占有欲是复杂的情感表现，受多种因素影响。适度的占有欲体现关心，
                但过度的占有欲可能影响关系健康。建议定期自我觉察，
                必要时寻求专业心理咨询帮助。
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={handleShare}
            className="flex-1 flex items-center justify-center gap-2 bg-white text-gray-700 font-semibold py-4 px-6 rounded-xl hover:shadow-lg transition-all"
          >
            <Share2 className="w-5 h-5" />
            分享结果
          </button>
          <button
            onClick={onRestart}
            className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold py-4 px-6 rounded-xl hover:shadow-lg transition-all"
          >
            <RotateCcw className="w-5 h-5" />
            重新测评
          </button>
        </div>

        <p className="text-center text-sm text-gray-500 mt-6">
          测评ID: {result.sessionId}
        </p>
      </div>
    </div>
  );
}
