import { Heart } from 'lucide-react';

interface HomeProps {
  onStart: () => void;
}

export function Home({ onStart }: HomeProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
      <div className="max-w-3xl w-full">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full mb-6 shadow-lg">
            <Heart className="w-10 h-10 text-white" fill="currentColor" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            RPI 恋爱占有欲指数测评
          </h1>
          <p className="text-lg text-gray-600 mb-2">
            Relationship Possessiveness Index
          </p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12 mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            关于这个测评
          </h2>

          <div className="space-y-4 text-gray-600 leading-relaxed mb-8">
            <p>
              RPI恋爱占有欲指数测评是一个基于心理学理论的自评工具，帮助你了解自己在亲密关系中的占有欲程度。
            </p>
            <p>
              通过20道精心设计的问题，我们将从<span className="font-semibold text-pink-600">控制欲望</span>、
              <span className="font-semibold text-purple-600">嫉妒倾向</span>、
              <span className="font-semibold text-pink-600">情感依赖</span>、
              <span className="font-semibold text-purple-600">关系不安</span>四个维度评估你的占有欲水平。
            </p>
          </div>

          <div className="bg-gradient-to-r from-pink-50 to-purple-50 rounded-2xl p-6 mb-8">
            <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              <span className="w-2 h-2 bg-pink-500 rounded-full"></span>
              测评特点
            </h3>
            <ul className="space-y-2 text-gray-600">
              <li>• 完全匿名，保护您的隐私</li>
              <li>• 基于心理学研究设计</li>
              <li>• 提供可视化结果分析</li>
              <li>• 给出个性化改善建议</li>
              <li>• 约需 3-5 分钟完成</li>
            </ul>
          </div>

          <div className="text-sm text-gray-500 mb-8 p-4 bg-gray-50 rounded-xl">
            <p className="font-semibold mb-2">重要提示：</p>
            <p>
              本测评仅供参考，不能替代专业心理咨询。测评结果反映的是你当前的状态，
              并非对你或你们关系的最终评判。每段关系都是独特的，请结合实际情况理性看待结果。
            </p>
          </div>

          <button
            onClick={onStart}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 text-white text-lg font-semibold py-4 px-8 rounded-xl hover:shadow-lg transform hover:scale-105 transition-all duration-200"
          >
            开始测评
          </button>
        </div>

        <p className="text-center text-sm text-gray-500">
          本测评基于心理学理论设计 · 结果仅供个人参考
        </p>
      </div>
    </div>
  );
}
